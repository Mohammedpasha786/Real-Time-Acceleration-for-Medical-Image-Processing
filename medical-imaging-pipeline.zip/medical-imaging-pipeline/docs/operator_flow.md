# Pipeline Operator Flow

## End-to-End Architecture

```
┌──────────────────────────────────────────────────────────────────────┐
│                    ACQUISITION LAYER                                  │
│                                                                      │
│  ADI High-Speed ADC Board  ──OR──  Simulated RF Data (.mat file)    │
│          (40 MHz, 128 ch)              (generate_simulated_rf.m)     │
└───────────────────────────┬──────────────────────────────────────────┘
                            │ RF frames [1024 x 128 float32]
                            ▼
┌──────────────────────────────────────────────────────────────────────┐
│  DataSourceOp                                                        │
│  • Reads .mat file OR streams from ADC                               │
│  • Emits one frame per compute() call at 30 fps                      │
└───────────────────────────┬──────────────────────────────────────────┘
                            │ rf_out → rf_in
                            ▼
┌──────────────────────────────────────────────────────────────────────┐
│  BeamformOp                                                          │
│  • Calls us_beamform_entry() — MATLAB GPU Coder CUDA                 │
│  • Delay-and-Sum beamforming on GPU                                  │
│  • Log-compression + envelope detection                              │
│  • Output: B-mode image [1024 x 128 float32]                         │
└───────────────────────────┬──────────────────────────────────────────┘
                            │ image_out → image_in
                            ▼
┌──────────────────────────────────────────────────────────────────────┐
│  EnhanceOp                                                           │
│  • Calls enhance_image_entry() — MATLAB GPU Coder CUDA               │
│  • Stage 1: Wiener filter (5×5) — speckle reduction                  │
│  • Stage 2: CLAHE (Rayleigh, clip=0.02) — contrast enhancement       │
│  • Output: enhanced image [512 x 512 float32]                        │
└───────────────────────────┬──────────────────────────────────────────┘
                            │ enhanced_out → image_in
                            ▼
┌──────────────────────────────────────────────────────────────────────┐
│  MedInferenceOp                                                      │
│  • Pre-process: resize to 224×224, replicate to 3ch                  │
│  • TensorRT inference on lesion_detector.onnx                        │
│  • Post-process: softmax → class label + confidence                  │
│  • Classes: benign | malignant | normal                              │
│  • Output: annotated entity with image + class_scores tensor         │
└───────────────────────────┬──────────────────────────────────────────┘
                            │ output → receivers
                            ▼
┌──────────────────────────────────────────────────────────────────────┐
│  HolovizOp (Holoscan built-in)                                       │
│  • Real-time GPU-accelerated rendering                               │
│  • Displays: enhanced B-mode image + classification overlay          │
│  • Window: 1280 × 720 at 30 fps                                      │
└──────────────────────────────────────────────────────────────────────┘
```

## Data Flow Summary

| Stage | Input Shape | Output Shape | Execution |
|---|---|---|---|
| DataSourceOp | file/ADC | `[1024 × 128]` float32 | CPU → GPU |
| BeamformOp | `[1024 × 128]` | `[1024 × 128]` float32 | GPU (CUDA) |
| EnhanceOp | `[1024 × 128]` | `[512 × 512]` float32 | GPU (CUDA) |
| MedInferenceOp | `[512 × 512]` | `[224 × 224 × 3]` → scores | GPU (TRT) |
| HolovizOp | annotated entity | display | GPU |

## MATLAB GPU Coder Integration

```
MATLAB function (us_beamform.m)
        │
        ▼ GPU Coder (generate_cuda_beamform.m)
CUDA library (us_beamform_entry.cu / .h)
        │
        ▼ CMake (cuda_generated/beamform/CMakeLists.txt)
Static library: libbeamform_cuda.a
        │
        ▼ linked into
Holoscan app (medical_pipeline)
```
