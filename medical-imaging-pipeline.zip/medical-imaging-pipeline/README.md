# Real-Time Acceleration for Medical Image Processing
**Project 259 — SR University | Industry Partner: Analog Devices / NVIDIA**

A complete end-to-end real-time medical imaging pipeline combining:
- **ADI high-speed ADC** (or simulated RF data) for signal acquisition
- **MATLAB + GPU Coder** for algorithm design and CUDA generation
- **NVIDIA Holoscan SDK** for real-time streaming deployment
- **TensorRT** for AI-based lesion classification

---

## Pipeline Overview

```
ADI ADC / Simulated RF
        ↓
  DataSourceOp          ← streams RF frames at 30 fps
        ↓
  BeamformOp            ← DAS beamforming (MATLAB GPU Coder CUDA)
        ↓
  EnhanceOp             ← Wiener + CLAHE (MATLAB GPU Coder CUDA)
        ↓
  MedInferenceOp        ← CNN lesion classifier (TensorRT, ONNX)
        ↓
  HolovizOp             ← real-time GPU display
```

---

## Repository Structure

```
medical-imaging-pipeline/
├── matlab/
│   ├── beamforming/
│   │   ├── us_beamform.m              # DAS beamformer (GPU Coder input)
│   │   ├── us_beamform_entry.m        # Entry-point wrapper
│   │   └── generate_cuda_beamform.m   # Runs GPU Coder → CUDA
│   ├── enhancement/
│   │   ├── enhance_image.m            # Wiener + CLAHE enhancement
│   │   ├── enhance_image_entry.m      # Entry-point wrapper
│   │   └── generate_cuda_enhance.m    # Runs GPU Coder → CUDA
│   └── ai_inference/
│       ├── train_cnn.m                # Train CNN on BUSI dataset
│       └── export_model_onnx.m        # Export to ONNX for TensorRT
├── cuda_generated/
│   ├── beamform/CMakeLists.txt        # Builds GPU Coder CUDA output
│   └── enhance/CMakeLists.txt
├── holoscan_app/
│   ├── CMakeLists.txt                 # Top-level build
│   ├── main.cpp                       # Pipeline definition
│   ├── operators/
│   │   ├── data_source_op.*           # RF data source
│   │   ├── beamform_op.*              # Wraps MATLAB CUDA beamformer
│   │   ├── enhance_op.*               # Wraps MATLAB CUDA enhancer
│   │   └── inference_op.*             # TensorRT lesion classifier
│   └── config/pipeline.yaml
├── data/
│   ├── download_busi.m                # Download BUSI dataset
│   └── generate_simulated_rf.m        # Generate test RF data
├── docker/Dockerfile
├── docs/operator_flow.md
└── README.md
```

---

## Step-by-Step Setup

### 1. Prerequisites

| Tool | Version | Purpose |
|---|---|---|
| MATLAB | R2023b+ | Algorithm development |
| GPU Coder Toolbox | R2023b+ | MATLAB → CUDA |
| Image Processing Toolbox | any | Enhancement functions |
| Phased Array System Toolbox | any | Beamforming |
| Deep Learning Toolbox | any | CNN training |
| CUDA Toolkit | 11.8+ | GPU compilation |
| NVIDIA Holoscan SDK | 1.0+ | Real-time pipeline |
| Docker + nvidia-container-toolkit | any | Container build |

---

### 2. Generate Simulated RF Data

```matlab
cd data/
run generate_simulated_rf.m
% Creates data/sample_rf_data.mat — 50 frames, 1024×128
```

---

### 3. Download BUSI Dataset

```matlab
cd data/
run download_busi.m
% Downloads and unzips to data/Dataset_BUSI_with_GT/
```

---

### 4. Train CNN and Export to ONNX

```matlab
cd matlab/ai_inference/
run train_cnn.m         % Trains on BUSI — saves models/lesion_classifier.mat
run export_model_onnx.m % Exports models/lesion_detector.onnx
```

---

### 5. Generate CUDA Code with GPU Coder

```matlab
% Beamformer
cd matlab/beamforming/
run generate_cuda_beamform.m
% Output: cuda_generated/beamform/  (us_beamform_entry.cu, .h)

% Enhancement
cd matlab/enhancement/
run generate_cuda_enhance.m
% Output: cuda_generated/enhance/  (enhance_image_entry.cu, .h)
```

---

### 6. Build Holoscan Application (Native)

```bash
cd holoscan_app
mkdir build && cd build
cmake -DBUILD_BEAMFORM=ON -DBUILD_ENHANCE=ON ..
make -j$(nproc)
./medical_pipeline ../config/pipeline.yaml
```

---

### 7. Build and Run with Docker

```bash
# Build container
docker build -t med-imaging-pipeline -f docker/Dockerfile .

# Run with GPU and X11 display
docker run --gpus all --rm -it \
  -e DISPLAY=$DISPLAY \
  -v /tmp/.X11-unix:/tmp/.X11-unix \
  med-imaging-pipeline
```

---

## Configuration

Edit `holoscan_app/config/pipeline.yaml` to tune parameters at runtime:

```yaml
beamform:
  speed_of_sound: 1540.0   # m/s
  sampling_freq:  40000000 # Hz
  element_pitch:  0.0003   # m

enhance:
  clahe_clip_limit: 0.02   # Lower = less aggressive contrast boost

inference:
  model_path: ../models/lesion_detector.onnx
  backend:    trt
```

---

## Performance Metrics

Measure and report the following for your submission:

| Metric | How to Measure |
|---|---|
| Latency per frame (ms) | `cudaEvent_t` start/stop around each operator compute() |
| Throughput (fps) | Count frames over 10 seconds, divide |
| GPU memory usage (MB) | `nvidia-smi` during pipeline run |
| Classification accuracy | Confusion matrix from `train_cnn.m` |
| Enhancement quality | PSNR / SSIM before vs. after enhance_image.m |

---

## Datasets

| Dataset | Usage | Reference |
|---|---|---|
| BUSI | CNN training | [doi:10.1016/j.dib.2019.104863](https://doi.org/10.1016/j.dib.2019.104863) |
| Zenodo raw RF signals | Beamformer validation | [doi:10.5281/zenodo.545928](https://doi.org/10.5281/zenodo.545928) |
| Plane Wave 75 Angles | Advanced beamforming | [zenodo.org/records/7986407](https://zenodo.org/records/7986407) |

---

## References

- [NVIDIA Holoscan SDK](https://developer.nvidia.com/holoscan-sdk)
- [HoloHub matlab_gpu_coder example](https://github.com/nvidia-holoscan/holohub/tree/main/applications/matlab_gpu_coder)
- [MATLAB GPU Coder Documentation](https://www.mathworks.com/products/gpu-coder.html)
- [ADI MathWorks Tools](https://github.com/analogdevicesinc/MathWorks_tools)

---

## Authors

SR University — Project 259  
Real-Time Acceleration for Medical Image Processing
