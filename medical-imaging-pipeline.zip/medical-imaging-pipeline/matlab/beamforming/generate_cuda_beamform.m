%% generate_cuda_beamform.m
% Runs MATLAB GPU Coder to generate CUDA library from us_beamform_entry.m
% Run this script from the matlab/beamforming/ directory.
% Prerequisites: GPU Coder toolbox, CUDA toolkit, compatible NVIDIA GPU.

%% Configure GPU Coder
cfg = coder.gpuConfig('lib');                   % Output: static CUDA library
cfg.GpuConfig.SelectCudaDevice        = 0;      % Use GPU device 0
cfg.GpuConfig.MallocMode              = 'discrete'; % Separate host/device memory
cfg.GenerateReport                    = true;
cfg.ReportPotentialDifferences        = false;
cfg.TargetLang                        = 'C++';

% Enable CUDA kernel profiling (optional, comment out in production)
% cfg.GpuConfig.EnableCUDAProfiler = true;

%% Define input argument types
% rf_data: single-precision matrix [1024 samples x 128 elements]
NUM_SAMPLES  = 1024;
NUM_ELEMENTS = 128;

ARGS = { ...
    coder.typeof(single(0), [NUM_SAMPLES, NUM_ELEMENTS], [0, 0]), ... % rf_data (fixed size)
    coder.typeof(single(0)),  ...   % fs           — scalar
    coder.typeof(single(0)),  ...   % c            — scalar
    coder.typeof(single(0)),  ...   % pitch        — scalar
    coder.typeof(int32(0))    ...   % num_elements — scalar
};

%% Output directory
output_dir = fullfile('..', '..', 'cuda_generated', 'beamform');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

%% Run codegen
fprintf('Generating CUDA code for beamformer...\n');
codegen -config cfg us_beamform_entry -args ARGS -d output_dir -report
fprintf('Done. CUDA files written to: %s\n', output_dir);
