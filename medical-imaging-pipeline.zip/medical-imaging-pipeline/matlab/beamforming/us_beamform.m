function img = us_beamform(rf_data, fs, c, pitch, num_elements)
% us_beamform - Delay-and-Sum (DAS) beamformer for ultrasound imaging
%
% Inputs:
%   rf_data      : [num_samples x num_elements] single-precision RF data matrix
%   fs           : Sampling frequency in Hz (e.g., 40e6)
%   c            : Speed of sound in m/s (e.g., 1540)
%   pitch        : Element pitch in meters (e.g., 3e-4)
%   num_elements : Number of transducer elements
%
% Output:
%   img          : [num_samples x num_elements] beamformed image (envelope detected)
%
% GPU Coder directive: generates a CUDA kernel per loop
coder.gpu.kernelfun();

[num_samples, ~] = size(rf_data);
img = zeros(num_samples, num_elements, 'like', rf_data);

% Delay-and-Sum beamforming
for i = 1:num_elements
    x_focus = (i - num_elements/2) * pitch;  % Lateral position of focus point
    for n = 1:num_samples
        % Axial depth from round-trip time
        z = (single(n) / fs) * c / 2.0;
        accumulated = single(0);
        for j = 1:num_elements
            x_elem = (single(j) - single(num_elements)/2.0) * pitch;
            % Travel distance from element j to focal point and back
            dist = sqrt((x_focus - x_elem)^2 + z^2);
            delay_samples = round((dist / c) * fs);
            sample_idx = int32(n) + int32(delay_samples);
            if sample_idx >= 1 && sample_idx <= int32(num_samples)
                accumulated = accumulated + rf_data(sample_idx, j);
            end
        end
        img(n, i) = accumulated;
    end
end

% Envelope detection via absolute value (Hilbert done outside for GPU compat)
img = abs(img);

% Log compression for display dynamic range
img = 20 .* log10(img ./ max(img(:)) + single(1e-6));
img = max(img, -60);  % Clip at -60 dB
end
