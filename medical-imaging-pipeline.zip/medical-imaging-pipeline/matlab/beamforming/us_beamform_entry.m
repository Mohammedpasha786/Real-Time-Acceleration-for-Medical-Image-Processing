function img = us_beamform_entry(rf_data, fs, c, pitch, num_elements) %#codegen
% us_beamform_entry - GPU Coder entry-point wrapper for us_beamform
%
% This function is the designated entry point for MATLAB GPU Coder.
% All input types must be fully specified (no variable-size unless declared).
% Called by generate_cuda_beamform.m during codegen.
%
% Inputs (fixed types for coder.typeof specification):
%   rf_data      : single [1024 x 128] — raw RF data
%   fs           : single scalar — sampling frequency
%   c            : single scalar — speed of sound
%   pitch        : single scalar — element pitch
%   num_elements : int32 scalar — number of elements
%
% Output:
%   img          : single [1024 x 128] — beamformed log-compressed image

img = us_beamform(rf_data, fs, c, pitch, num_elements);
end
