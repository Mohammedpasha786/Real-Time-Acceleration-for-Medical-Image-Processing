%% generate_cuda_enhance.m
% Runs MATLAB GPU Coder to generate CUDA library from enhance_image_entry.m
% Run this script from the matlab/enhancement/ directory.

%% GPU Coder configuration
cfg = coder.gpuConfig('lib');
cfg.GpuConfig.SelectCudaDevice    = 0;
cfg.GpuConfig.MallocMode          = 'discrete';
cfg.GenerateReport                = true;
cfg.ReportPotentialDifferences    = false;
cfg.TargetLang                    = 'C++';

%% Input argument types
% img: single-precision [512 x 512] image
IMG_H = 512;
IMG_W = 512;

ARGS = { ...
    coder.typeof(single(0), [IMG_H, IMG_W], [0, 0]) ...  % img (fixed size)
};

%% Output directory
output_dir = fullfile('..', '..', 'cuda_generated', 'enhance');
if ~exist(output_dir, 'dir')
    mkdir(output_dir);
end

%% Run codegen
fprintf('Generating CUDA code for image enhancement...\n');
codegen -config cfg enhance_image_entry -args ARGS -d output_dir -report
fprintf('Done. CUDA files written to: %s\n', output_dir);
