function out = enhance_image_entry(img) %#codegen
% enhance_image_entry - GPU Coder entry-point wrapper for enhance_image
%
% Fixed input size: single [512 x 512] grayscale image.
% Adjust dimensions to match your beamformed image output size.

out = enhance_image(img);
end
