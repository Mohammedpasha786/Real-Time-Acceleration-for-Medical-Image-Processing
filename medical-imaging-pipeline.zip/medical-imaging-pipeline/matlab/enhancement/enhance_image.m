function out = enhance_image(img)
% enhance_image - Image enhancement pipeline for ultrasound B-mode images
%
% Applies a two-stage pipeline:
%   1. Wiener filter (5x5) for speckle noise suppression
%   2. Contrast-Limited Adaptive Histogram Equalization (CLAHE)
%      using Rayleigh distribution suited for ultrasound speckle statistics
%
% Input:
%   img : [H x W] single-precision grayscale image (values 0–1 or log-compressed)
%
% Output:
%   out : [H x W] single-precision enhanced image (values 0–1)
%
% GPU Coder directive
coder.gpu.kernelfun();

%% Normalize input to [0, 1]
img_min = min(img(:));
img_max = max(img(:));
if img_max > img_min
    img_norm = (img - img_min) ./ (img_max - img_min);
else
    img_norm = img;
end
img_norm = single(img_norm);

%% Stage 1: Wiener filter for speckle reduction
% Estimates local mean and variance to suppress noise while preserving edges
img_wiener = wiener2(img_norm, [5, 5]);

%% Stage 2: Adaptive Histogram Equalization
% ClipLimit controls contrast enhancement (0.02 is conservative for medical imaging)
% Rayleigh distribution matches ultrasound speckle statistics
img_clahe = adapthisteq(img_wiener, ...
    'ClipLimit',    0.02, ...
    'Distribution', 'rayleigh', ...
    'NumTiles',     [8, 8], ...
    'NBins',        256, ...
    'Range',        'full');

out = single(img_clahe);
end
