%% export_model_onnx.m
% Exports the trained MATLAB CNN to ONNX format for TensorRT deployment
% in the Holoscan inference operator.
%
% Prerequisites:
%   - Deep Learning Toolbox
%   - Deep Learning Toolbox Converter for ONNX Model Format (add-on)
%   - Trained model saved by train_cnn.m

clear; clc;

%% ---- 1. Load trained network -----------------------------------------
modelPath = fullfile('..', '..', 'models', 'lesion_classifier.mat');
if ~exist(modelPath, 'file')
    error('Trained model not found. Run train_cnn.m first.');
end
load(modelPath, 'net');
fprintf('Loaded network: %s\n', class(net));

%% ---- 2. Export to ONNX -----------------------------------------------
onnxPath = fullfile('..', '..', 'models', 'lesion_detector.onnx');

% exportONNXNetwork requires Deep Learning Toolbox Converter add-on
exportONNXNetwork(net, onnxPath);
fprintf('ONNX model exported to: %s\n', onnxPath);

%% ---- 3. Verify ONNX model can be re-imported -----------------------
netOnnx = importONNXNetwork(onnxPath, ...
    'OutputLayerType', 'classification', ...
    'Classes',         categories(net.Layers(end).Classes));
fprintf('ONNX re-import successful. Output classes: %s\n', ...
    strjoin(string(categories(net.Layers(end).Classes)), ', '));

%% ---- 4. Print model input/output info --------------------------------
inputLayer  = net.Layers(1);
outputLayer = net.Layers(end);
fprintf('\nModel Input  : %s — size %s\n', inputLayer.Name,  mat2str(inputLayer.InputSize));
fprintf('Model Output : %s — %d classes\n', outputLayer.Name, numel(outputLayer.Classes));

fprintf('\nDone. Deploy lesion_detector.onnx with TensorRT in Holoscan.\n');
