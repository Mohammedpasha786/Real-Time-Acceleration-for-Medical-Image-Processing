%% train_cnn.m
% Train a lightweight CNN for breast lesion classification on the BUSI dataset.
% Classes: benign | malignant | normal
%
% Prerequisites:
%   - Deep Learning Toolbox
%   - BUSI dataset downloaded (run download_busi.m first)
%   - GPU recommended (falls back to CPU automatically)

clear; clc;

%% ---- 1. Dataset path ------------------------------------------------
dataDir = fullfile('..', '..', 'data', 'Dataset_BUSI_with_GT');
if ~exist(dataDir, 'dir')
    error('BUSI dataset not found. Run data/download_busi.m first.');
end

%% ---- 2. Load images using imageDatastore --------------------------
imds = imageDatastore(dataDir, ...
    'IncludeSubfolders', true, ...
    'LabelSource',       'foldernames', ...
    'FileExtensions',    {'.png', '.jpg', '.bmp'});

% Exclude mask images (filenames contain '_mask')
isMask = contains(imds.Files, '_mask');
imds   = subset(imds, ~isMask);

fprintf('Total images: %d\n', numel(imds.Files));
disp(countEachLabel(imds));

%% ---- 3. Train / validation split (80 / 20) -----------------------
[imdsTrain, imdsVal] = splitEachLabel(imds, 0.8, 'randomized');

%% ---- 4. Image augmentation & preprocessing -----------------------
inputSize = [224, 224, 3];   % Match network input

augTrain = imageDataAugmenter( ...
    'RandXReflection',  true, ...
    'RandRotation',     [-15, 15], ...
    'RandXScale',       [0.9, 1.1], ...
    'RandYScale',       [0.9, 1.1]);

augImds      = augmentedImageDatastore(inputSize, imdsTrain, 'DataAugmentation', augTrain);
augImdsVal   = augmentedImageDatastore(inputSize, imdsVal);

%% ---- 5. Network architecture (lightweight CNN) -------------------
numClasses = numel(categories(imds.Labels));

layers = [
    imageInputLayer(inputSize, 'Name', 'input', 'Normalization', 'zerocenter')

    % Block 1
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1')
    batchNormalizationLayer('Name', 'bn1')
    reluLayer('Name', 'relu1')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool1')

    % Block 2
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2')
    batchNormalizationLayer('Name', 'bn2')
    reluLayer('Name', 'relu2')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool2')

    % Block 3
    convolution2dLayer(3, 128, 'Padding', 'same', 'Name', 'conv3')
    batchNormalizationLayer('Name', 'bn3')
    reluLayer('Name', 'relu3')
    maxPooling2dLayer(2, 'Stride', 2, 'Name', 'pool3')

    % Classifier head
    globalAveragePooling2dLayer('Name', 'gap')
    dropoutLayer(0.5, 'Name', 'dropout')
    fullyConnectedLayer(numClasses, 'Name', 'fc')
    softmaxLayer('Name', 'softmax')
    classificationLayer('Name', 'output')
];

%% ---- 6. Training options -----------------------------------------
opts = trainingOptions('adam', ...
    'MaxEpochs',            30, ...
    'MiniBatchSize',        32, ...
    'InitialLearnRate',     1e-4, ...
    'LearnRateSchedule',    'piecewise', ...
    'LearnRateDropFactor',  0.5, ...
    'LearnRateDropPeriod',  10, ...
    'ValidationData',       augImdsVal, ...
    'ValidationFrequency',  20, ...
    'Shuffle',              'every-epoch', ...
    'Verbose',              true, ...
    'Plots',                'training-progress', ...
    'ExecutionEnvironment', 'auto');   % Uses GPU if available

%% ---- 7. Train --------------------------------------------------------
fprintf('Training CNN...\n');
net = trainNetwork(augImds, layers, opts);

%% ---- 8. Evaluate on validation set -----------------------------------
predLabels = classify(net, augImdsVal);
trueLabels = imdsVal.Labels;
acc = mean(predLabels == trueLabels);
fprintf('Validation Accuracy: %.2f%%\n', acc * 100);

confusionchart(trueLabels, predLabels);
title('Validation Confusion Matrix');

%% ---- 9. Save trained network -----------------------------------------
modelSavePath = fullfile('..', '..', 'models', 'lesion_classifier.mat');
save(modelSavePath, 'net');
fprintf('Model saved to: %s\n', modelSavePath);
