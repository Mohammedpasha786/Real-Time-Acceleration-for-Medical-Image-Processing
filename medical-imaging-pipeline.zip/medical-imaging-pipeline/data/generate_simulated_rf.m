%% generate_simulated_rf.m
% Generates a synthetic ultrasound RF dataset for testing the pipeline
% without real hardware. Saves as sample_rf_data.mat.
%
% The simulation models plane-wave transmission from a linear array
% with point scatterers at random depths, producing realistic-looking
% RF channel data.

clear; clc;

%% Parameters
fs           = 40e6;       % Sampling frequency (Hz)
c            = 1540;       % Speed of sound (m/s)
fc           = 5e6;        % Center frequency (Hz)
num_elements = 128;        % Number of transducer elements
num_samples  = 1024;       % Samples per RF line
pitch        = 3e-4;       % Element pitch (m)
num_frames   = 50;         % Number of frames to generate

%% Scatterer positions (simulated tissue)
rng(42);
num_scatterers = 200;
scat_x = (rand(num_scatterers, 1) - 0.5) * (num_elements * pitch);  % Lateral
scat_z = rand(num_scatterers, 1) * (num_samples / fs * c / 2);       % Axial depth

% Add a simulated lesion cluster near center
lesion_x = 0;
lesion_z = 0.025;   % 25 mm depth
lesion_r = 0.005;   % 5 mm radius
lesion_x_pts = lesion_x + lesion_r * (2*rand(20,1)-1);
lesion_z_pts = lesion_z + lesion_r * (2*rand(20,1)-1);
scat_x = [scat_x; lesion_x_pts];
scat_z = [scat_z; lesion_z_pts];
scat_amp = [rand(num_scatterers,1); 3*ones(20,1)];  % Lesion scatters brighter

%% Generate RF data frames
rf_frames = zeros(num_samples, num_elements, num_frames, 'single');
t = (0:num_samples-1)' / fs;
pulse = sin(2*pi*fc*t) .* exp(-((t - 2/fc).^2) / (2*(0.5/fc)^2));  % Gaussian-modulated sine

for f = 1:num_frames
    rf = zeros(num_samples, num_elements, 'single');
    for s = 1:numel(scat_x)
        for e = 1:num_elements
            elem_x = (e - num_elements/2) * pitch;
            dist = sqrt((scat_x(s) - elem_x)^2 + scat_z(s)^2);
            delay_idx = round((dist / c) * fs * 2);
            if delay_idx >= 1 && delay_idx <= num_samples
                window = max(1, delay_idx-10):min(num_samples, delay_idx+10);
                rf(window, e) = rf(window, e) + ...
                    scat_amp(s) * pulse(1:numel(window)) * (1/dist);
            end
        end
    end
    % Add thermal noise
    rf = rf + 0.01 * randn(size(rf), 'single');
    rf_frames(:, :, f) = rf;
end

%% Save
outPath = fullfile(fileparts(mfilename('fullpath')), 'sample_rf_data.mat');
save(outPath, 'rf_frames', 'fs', 'c', 'pitch', 'num_elements', 'num_samples', 'fc', '-v7.3');
fprintf('Saved %d frames of RF data to: %s\n', num_frames, outPath);
fprintf('Data shape: [%d x %d x %d] (samples x elements x frames)\n', ...
    num_samples, num_elements, num_frames);
