%% download_busi.m
% Downloads and unzips the Breast Ultrasound Images (BUSI) dataset.
%
% Citation:
%   Al-Dhabyani W, Gomaa M, Khaled H, Fahmy A.
%   "Dataset of Breast Ultrasound Images." Data in Brief 28 (2020): 104863.
%   https://doi.org/10.1016/j.dib.2019.104863
%
% The dataset contains 780 images in 3 classes:
%   benign/ malignant/ normal/

clear; clc;

dataDir = fullfile(fileparts(mfilename('fullpath')));

fprintf('Downloading BUSI dataset...\n');
zipFile = matlab.internal.examples.downloadSupportFile('image', 'data/Dataset_BUSI.zip');

fprintf('Unzipping to: %s\n', dataDir);
unzip(zipFile, dataDir);

fprintf('Done. Dataset available at: %s\n', fullfile(dataDir, 'Dataset_BUSI_with_GT'));
fprintf('Classes found:\n');
d = dir(fullfile(dataDir, 'Dataset_BUSI_with_GT'));
for i = 1:numel(d)
    if d(i).isdir && ~startsWith(d(i).name, '.')
        imgs = dir(fullfile(d(i).folder, d(i).name, '*.png'));
        % Exclude mask files
        isMask = contains({imgs.name}, '_mask');
        fprintf('  %-12s : %d images\n', d(i).name, sum(~isMask));
    end
end
