// operators/inference_op.cpp
// Runs ONNX/TensorRT lesion classification inference.
// The ONNX model is produced by matlab/ai_inference/export_model_onnx.m
// and converted to a TensorRT engine on first run via Holoscan's inference
// utilities (or trtexec offline).

#include "inference_op.hpp"
#include <holoscan/holoscan.hpp>
#include <cuda_runtime.h>
#include <algorithm>
#include <numeric>
#include <cmath>
#include <iostream>

namespace ops {

// ---- Softmax helper (host-side on small output vector) ---------------
static std::vector<float> softmax(const float* logits, int n) {
    std::vector<float> probs(n);
    float max_v = *std::max_element(logits, logits + n);
    float sum = 0.0f;
    for (int i = 0; i < n; i++) {
        probs[i] = std::exp(logits[i] - max_v);
        sum += probs[i];
    }
    for (auto& p : probs) p /= sum;
    return probs;
}

// ---- Operator setup --------------------------------------------------
void MedInferenceOp::setup(holoscan::OperatorSpec& spec) {
    spec.param(model_path_,   "model_path",   "ONNX Model Path",   "",
               std::string("../models/lesion_detector.onnx"));
    spec.param(backend_,      "backend",      "Inference Backend", "",
               std::string("trt"));
    spec.param(input_width_,  "input_width",  "Model Input Width",  "", 224);
    spec.param(input_height_, "input_height", "Model Input Height", "", 224);

    spec.input<holoscan::gxf::Entity>("image_in");
    spec.output<holoscan::gxf::Entity>("output");
}

void MedInferenceOp::start() {
    int w = input_width_.get();
    int h = input_height_.get();

    // Allocate pre-processed input buffer (3-channel RGB for CNN)
    CUDA_TRY(cudaMalloc(&d_input_resized_, 3 * h * w * sizeof(float)));

    // Allocate output scores buffer (one float per class)
    CUDA_TRY(cudaMallocHost(&d_output_scores_, num_classes_ * sizeof(float)));

    HOLOSCAN_LOG_INFO("MedInferenceOp: model={}, backend={}, input={}x{}",
        model_path_.get(), backend_.get(), w, h);

    // NOTE: In a full implementation, load and deserialize the TensorRT engine here.
    // Example (using NvInfer):
    //   auto builder = nvinfer1::createInferBuilder(logger);
    //   auto network = builder->createNetworkV2(...);
    //   auto parser  = nvonnxparser::createParser(*network, logger);
    //   parser->parseFromFile(model_path_.get().c_str(), ...);
    //   trt_context_ = engine->createExecutionContext();
    //
    // For this reference implementation we log a stub warning.
    HOLOSCAN_LOG_WARN("MedInferenceOp: TensorRT engine loading is stubbed.");
    HOLOSCAN_LOG_WARN("Integrate NvInfer or use Holoscan InferenceOp for production.");
}

void MedInferenceOp::compute(holoscan::InputContext&    in,
                               holoscan::OutputContext&   out,
                               holoscan::ExecutionContext& ctx) {
    auto in_entity = in.receive<holoscan::gxf::Entity>("image_in").value();
    auto in_tensor = in_entity.get<nvidia::gxf::Tensor>("image");
    float* d_img   = static_cast<float*>(in_tensor->pointer());

    auto shape = in_tensor->shape();
    int src_h  = shape.dimension(0);
    int src_w  = shape.dimension(1);

    // Pre-process: resize + normalize to [0,1], replicate to 3 channels
    preprocess(d_img, src_h, src_w,
               d_input_resized_, input_height_.get(), input_width_.get());

    // ---- TensorRT inference (stubbed) --------------------------------
    // Production: run trt_context_->executeV2(bindings) here.
    // Stub: produce uniform scores so pipeline stays runnable without model.
    float stub_scores[3] = {0.6f, 0.3f, 0.1f};
    std::memcpy(d_output_scores_, stub_scores, 3 * sizeof(float));

    // Post-process: softmax + argmax
    auto probs      = softmax(d_output_scores_, num_classes_);
    int  pred_class = static_cast<int>(
        std::max_element(probs.begin(), probs.end()) - probs.begin());
    float confidence = probs[pred_class];

    HOLOSCAN_LOG_INFO("Inference: {} ({:.1f}%)",
        class_labels_[pred_class], confidence * 100.0f);

    // Emit annotated entity (downstream Holoviz will display the image)
    auto out_entity = holoscan::gxf::Entity::New(&ctx);

    // Re-attach the input image for visualization
    auto out_img = out_entity.add<nvidia::gxf::Tensor>("image");
    std::array<int32_t, 2> img_shape = {src_h, src_w};
    out_img->wrapMemory(
        nvidia::gxf::Shape{img_shape},
        nvidia::gxf::PrimitiveType::kFloat32,
        sizeof(float),
        nvidia::gxf::Unexpected{},
        nvidia::gxf::MemoryStorageType::kDevice,
        d_img,
        [](void*) { return nvidia::gxf::Success; }
    );

    // Add classification result as a scalar tensor for overlay rendering
    auto result_tensor = out_entity.add<nvidia::gxf::Tensor>("class_scores");
    result_tensor->reshape<float>(
        nvidia::gxf::Shape{{num_classes_}},
        nvidia::gxf::MemoryStorageType::kHost,
        nullptr
    );
    std::memcpy(result_tensor->pointer(), probs.data(), num_classes_ * sizeof(float));

    out.emit(out_entity, "output");
}

void MedInferenceOp::stop() {
    if (d_input_resized_) { cudaFree(d_input_resized_);       d_input_resized_ = nullptr; }
    if (d_output_scores_) { cudaFreeHost(d_output_scores_);   d_output_scores_ = nullptr; }
    HOLOSCAN_LOG_INFO("MedInferenceOp stopped.");
}

void MedInferenceOp::preprocess(float* d_src, int src_h, int src_w,
                                  float* d_dst, int dst_h, int dst_w) {
    // In production: launch a CUDA kernel that bilinearly resizes the
    // single-channel image to [dst_h x dst_w], normalises to [0,1],
    // and replicates the channel 3 times for the CNN RGB input.
    // Stub: memset to zero (safe no-op for the pipeline).
    CUDA_TRY(cudaMemset(d_dst, 0, 3 * dst_h * dst_w * sizeof(float)));
}

int MedInferenceOp::argmax(const float* scores, int n) {
    return static_cast<int>(std::max_element(scores, scores + n) - scores);
}

}  // namespace ops
