// operators/data_source_op.cpp
// Implementation of DataSourceOp.
// Loads RF frame data and emits one frame per compute() call.
// Loops over dataset if loop_ == true (for demo/testing).

#include "data_source_op.hpp"
#include <holoscan/holoscan.hpp>
#include <stdexcept>
#include <cstring>
#include <iostream>
#include <thread>
#include <chrono>

namespace ops {

void DataSourceOp::setup(holoscan::OperatorSpec& spec) {
    spec.param(data_path_,  "data_path",  "Data Path",
               "Path to .mat file containing rf_frames variable",
               std::string("../data/sample_rf_data.mat"));
    spec.param(frame_rate_, "frame_rate", "Frame Rate",
               "Target output frame rate (fps)", 30);
    spec.param(loop_,       "loop",       "Loop",
               "Loop dataset continuously", true);

    spec.output<holoscan::gxf::Entity>("rf_out");
}

void DataSourceOp::start() {
    load_mat_file(data_path_.get());
    HOLOSCAN_LOG_INFO("DataSourceOp: Loaded {} frames [{} samples x {} elements]",
                      total_frames_, num_samples_, num_elements_);
}

void DataSourceOp::compute(holoscan::InputContext&  /*in*/,
                            holoscan::OutputContext&  out,
                            holoscan::ExecutionContext& ctx) {
    if (total_frames_ == 0) {
        HOLOSCAN_LOG_ERROR("No RF data loaded.");
        return;
    }

    // Frame pacing
    int fps = frame_rate_.get();
    if (fps > 0) {
        std::this_thread::sleep_for(
            std::chrono::milliseconds(1000 / fps));
    }

    // Allocate output entity
    auto entity = holoscan::gxf::Entity::New(&ctx);
    auto tensor = entity.add<nvidia::gxf::Tensor>("rf_data");

    // Shape: [num_samples, num_elements]
    std::array<int32_t, 2> shape = {num_samples_, num_elements_};
    tensor->reshape<float>(
        nvidia::gxf::Shape{shape},
        nvidia::gxf::MemoryStorageType::kDevice,  // GPU memory
        nullptr
    );

    // Copy frame data to tensor (host → device)
    const auto& frame = rf_frames_[current_frame_];
    CUDA_TRY(cudaMemcpy(
        tensor->pointer(),
        frame.data(),
        frame.size() * sizeof(float),
        cudaMemcpyHostToDevice
    ));

    out.emit(entity, "rf_out");

    // Advance frame counter
    current_frame_++;
    if (current_frame_ >= total_frames_) {
        if (loop_.get()) {
            current_frame_ = 0;
            HOLOSCAN_LOG_INFO("DataSourceOp: Looping dataset.");
        } else {
            HOLOSCAN_LOG_INFO("DataSourceOp: End of dataset.");
        }
    }
}

void DataSourceOp::stop() {
    rf_frames_.clear();
    HOLOSCAN_LOG_INFO("DataSourceOp stopped.");
}

void DataSourceOp::load_mat_file(const std::string& path) {
    // NOTE: Production code should use a MAT file library (e.g., matio).
    // For this reference implementation, we generate synthetic data
    // identical to what generate_simulated_rf.m produces, so the pipeline
    // can be built and tested without the matio dependency.
    //
    // To enable real MAT loading:
    //   1. Install matio: apt-get install libmatio-dev
    //   2. link target_link_libraries with matio
    //   3. Replace the block below with matio read calls.

    HOLOSCAN_LOG_WARN("DataSourceOp: Using synthetic RF data (MAT loader stub).");
    HOLOSCAN_LOG_WARN("To load real data, integrate libmatio (see data_source_op.cpp).");

    // Synthetic data: 50 frames of Gaussian noise RF signals
    total_frames_   = 50;
    num_samples_    = 1024;
    num_elements_   = 128;

    rf_frames_.resize(total_frames_,
        std::vector<float>(num_samples_ * num_elements_, 0.0f));

    std::srand(42);
    for (auto& frame : rf_frames_) {
        for (auto& v : frame) {
            v = static_cast<float>(std::rand()) / RAND_MAX * 2.0f - 1.0f;
        }
    }
}

}  // namespace ops
