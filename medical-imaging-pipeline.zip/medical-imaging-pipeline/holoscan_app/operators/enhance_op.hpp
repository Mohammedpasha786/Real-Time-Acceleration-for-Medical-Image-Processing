// operators/enhance_op.hpp
// Holoscan operator wrapping the MATLAB GPU Coder generated
// image enhancement CUDA library (enhance_image_entry).
//
// Input:  image_in     — [H x W] float32 beamformed image (GPU)
// Output: enhanced_out — [H x W] float32 enhanced image (GPU)

#pragma once

#include <holoscan/holoscan.hpp>

namespace ops {

class EnhanceOp : public holoscan::Operator {
public:
    HOLOSCAN_OPERATOR_FORWARD_ARGS(EnhanceOp)
    EnhanceOp() = default;

    void setup(holoscan::OperatorSpec& spec) override;
    void start() override;
    void compute(holoscan::InputContext&    in,
                 holoscan::OutputContext&   out,
                 holoscan::ExecutionContext& ctx) override;
    void stop() override;

private:
    holoscan::Parameter<int>   wiener_kernel_size_;
    holoscan::Parameter<float> clahe_clip_limit_;

    float* d_output_ = nullptr;
    int    img_h_ = 512;
    int    img_w_ = 512;
};

}  // namespace ops
