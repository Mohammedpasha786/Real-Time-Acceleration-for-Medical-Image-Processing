// operators/enhance_op.cpp
// Calls MATLAB GPU Coder generated enhance_image_entry() CUDA function.
// Generated header "enhance_image_entry.h" is produced by running
// matlab/enhancement/generate_cuda_enhance.m

#include "enhance_op.hpp"
#include <holoscan/holoscan.hpp>
#include <cuda_runtime.h>

#ifdef ENABLE_ENHANCE
#include "enhance_image_entry.h"
#endif

namespace ops {

void EnhanceOp::setup(holoscan::OperatorSpec& spec) {
    spec.param(wiener_kernel_size_, "wiener_kernel_size",
               "Wiener Filter Kernel Size", "", 5);
    spec.param(clahe_clip_limit_,  "clahe_clip_limit",
               "CLAHE Clip Limit", "", 0.02f);

    spec.input<holoscan::gxf::Entity>("image_in");
    spec.output<holoscan::gxf::Entity>("enhanced_out");
}

void EnhanceOp::start() {
    CUDA_TRY(cudaMalloc(&d_output_, img_h_ * img_w_ * sizeof(float)));
    CUDA_TRY(cudaMemset(d_output_, 0, img_h_ * img_w_ * sizeof(float)));

#ifdef ENABLE_ENHANCE
    enhance_image_entry_initialize();
#endif

    HOLOSCAN_LOG_INFO("EnhanceOp started: {}x{} image, wiener kernel={}, CLAHE clip={}",
        img_h_, img_w_, wiener_kernel_size_.get(), clahe_clip_limit_.get());
}

void EnhanceOp::compute(holoscan::InputContext&    in,
                         holoscan::OutputContext&   out,
                         holoscan::ExecutionContext& ctx) {
    auto in_entity  = in.receive<holoscan::gxf::Entity>("image_in").value();
    auto in_tensor  = in_entity.get<nvidia::gxf::Tensor>("image");
    float* d_input  = static_cast<float*>(in_tensor->pointer());

#ifdef ENABLE_ENHANCE
    // Call MATLAB GPU Coder generated CUDA function
    // Signature: void enhance_image_entry(const float* img, float* out,
    //                                     int H, int W)
    enhance_image_entry(d_input, d_output_, img_h_, img_w_);
#else
    // Fallback: pass through unchanged
    size_t nbytes = img_h_ * img_w_ * sizeof(float);
    CUDA_TRY(cudaMemcpy(d_output_, d_input, nbytes, cudaMemcpyDeviceToDevice));
#endif

    CUDA_TRY(cudaDeviceSynchronize());

    // Emit enhanced image
    auto out_entity = holoscan::gxf::Entity::New(&ctx);
    auto out_tensor = out_entity.add<nvidia::gxf::Tensor>("image");
    std::array<int32_t, 2> shape = {img_h_, img_w_};
    out_tensor->wrapMemory(
        nvidia::gxf::Shape{shape},
        nvidia::gxf::PrimitiveType::kFloat32,
        sizeof(float),
        nvidia::gxf::Unexpected{},
        nvidia::gxf::MemoryStorageType::kDevice,
        d_output_,
        [](void*) { return nvidia::gxf::Success; }
    );

    out.emit(out_entity, "enhanced_out");
}

void EnhanceOp::stop() {
    if (d_output_) {
        cudaFree(d_output_);
        d_output_ = nullptr;
    }

#ifdef ENABLE_ENHANCE
    enhance_image_entry_terminate();
#endif

    HOLOSCAN_LOG_INFO("EnhanceOp stopped.");
}

}  // namespace ops
