// operators/beamform_op.hpp
// Holoscan operator that wraps the MATLAB GPU Coder generated CUDA
// beamforming library (us_beamform_entry).
//
// Input:  rf_in  — [num_samples x num_elements] float32 tensor (GPU)
// Output: image_out — [num_samples x num_elements] float32 beamformed image (GPU)

#pragma once

#include <holoscan/holoscan.hpp>

namespace ops {

class BeamformOp : public holoscan::Operator {
public:
    HOLOSCAN_OPERATOR_FORWARD_ARGS(BeamformOp)
    BeamformOp() = default;

    void setup(holoscan::OperatorSpec& spec) override;
    void start() override;
    void compute(holoscan::InputContext&    in,
                 holoscan::OutputContext&   out,
                 holoscan::ExecutionContext& ctx) override;
    void stop() override;

private:
    holoscan::Parameter<float> speed_of_sound_;
    holoscan::Parameter<float> sampling_freq_;
    holoscan::Parameter<float> element_pitch_;
    holoscan::Parameter<int>   num_elements_;

    // Device (GPU) output buffer
    float* d_output_ = nullptr;
    int    output_size_ = 0;
};

}  // namespace ops
