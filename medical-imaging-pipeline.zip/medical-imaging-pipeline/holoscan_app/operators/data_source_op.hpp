// operators/data_source_op.hpp
// Holoscan operator that reads RF ultrasound frames from a .mat file
// and emits them one frame at a time to downstream operators.
// If ADI hardware is available, this operator can be extended to
// read live data from the ADC board over USB/PCIe.

#pragma once

#include <holoscan/holoscan.hpp>
#include <string>
#include <vector>

namespace ops {

class DataSourceOp : public holoscan::Operator {
public:
    HOLOSCAN_OPERATOR_FORWARD_ARGS(DataSourceOp)
    DataSourceOp() = default;

    void setup(holoscan::OperatorSpec& spec) override;
    void start() override;
    void compute(holoscan::InputContext&  in,
                 holoscan::OutputContext& out,
                 holoscan::ExecutionContext& ctx) override;
    void stop() override;

private:
    // Parameters
    holoscan::Parameter<std::string> data_path_;
    holoscan::Parameter<int>         frame_rate_;
    holoscan::Parameter<bool>        loop_;

    // Internal state
    std::vector<std::vector<float>>  rf_frames_;   // [frame][sample*element]
    int                              num_samples_    = 1024;
    int                              num_elements_   = 128;
    size_t                           current_frame_  = 0;
    size_t                           total_frames_   = 0;

    // Helpers
    void load_mat_file(const std::string& path);
};

}  // namespace ops
