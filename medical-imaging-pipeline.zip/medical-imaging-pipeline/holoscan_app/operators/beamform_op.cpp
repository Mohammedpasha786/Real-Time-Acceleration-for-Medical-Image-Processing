// operators/beamform_op.cpp
// Calls MATLAB GPU Coder generated us_beamform_entry() CUDA function.
// The generated header "us_beamform_entry.h" is produced by running
// matlab/beamforming/generate_cuda_beamform.m

#include "beamform_op.hpp"
#include <holoscan/holoscan.hpp>
#include <cuda_runtime.h>

#ifdef ENABLE_BEAMFORM
// Include MATLAB GPU Coder generated header
// (Available after running generate_cuda_beamform.m)
#include "us_beamform_entry.h"
#endif

namespace ops {

void BeamformOp::setup(holoscan::OperatorSpec& spec) {
    spec.param(speed_of_sound_, "speed_of_sound", "Speed of Sound (m/s)", "", 1540.0f);
    spec.param(sampling_freq_,  "sampling_freq",  "Sampling Frequency (Hz)", "", 40.0e6f);
    spec.param(element_pitch_,  "element_pitch",  "Element Pitch (m)", "", 3.0e-4f);
    spec.param(num_elements_,   "num_elements",   "Number of Elements", "", 128);

    spec.input<holoscan::gxf::Entity>("rf_in");
    spec.output<holoscan::gxf::Entity>("image_out");
}

void BeamformOp::start() {
    int num_samples  = 1024;
    int num_elements = num_elements_.get();
    output_size_ = num_samples * num_elements;

    // Pre-allocate persistent GPU output buffer
    CUDA_TRY(cudaMalloc(&d_output_, output_size_ * sizeof(float)));
    CUDA_TRY(cudaMemset(d_output_, 0, output_size_ * sizeof(float)));

#ifdef ENABLE_BEAMFORM
    // Initialize MATLAB GPU Coder generated runtime
    us_beamform_entry_initialize();
#endif

    HOLOSCAN_LOG_INFO("BeamformOp started: {} samples x {} elements, fs={:.1e}Hz, c={}m/s",
        num_samples, num_elements, sampling_freq_.get(), speed_of_sound_.get());
}

void BeamformOp::compute(holoscan::InputContext&    in,
                          holoscan::OutputContext&   out,
                          holoscan::ExecutionContext& ctx) {
    // Receive RF data entity
    auto rf_entity = in.receive<holoscan::gxf::Entity>("rf_in").value();
    auto rf_tensor = rf_entity.get<nvidia::gxf::Tensor>("rf_data");
    float* d_rf = static_cast<float*>(rf_tensor->pointer());

#ifdef ENABLE_BEAMFORM
    // Call MATLAB GPU Coder generated CUDA function
    // Signature produced by GPU Coder from us_beamform_entry.m:
    //   void us_beamform_entry(const float* rf_data, float fs, float c,
    //                          float pitch, int num_elements, float* img)
    us_beamform_entry(
        d_rf,
        sampling_freq_.get(),
        speed_of_sound_.get(),
        element_pitch_.get(),
        num_elements_.get(),
        d_output_
    );
#else
    // Fallback: pass RF data through unchanged (for pipeline testing)
    CUDA_TRY(cudaMemcpy(d_output_, d_rf,
        output_size_ * sizeof(float), cudaMemcpyDeviceToDevice));
#endif

    CUDA_TRY(cudaDeviceSynchronize());

    // Pack output into new entity
    auto out_entity = holoscan::gxf::Entity::New(&ctx);
    auto out_tensor = out_entity.add<nvidia::gxf::Tensor>("image");
    std::array<int32_t, 2> shape = {1024, num_elements_.get()};
    out_tensor->wrapMemory(
        nvidia::gxf::Shape{shape},
        nvidia::gxf::PrimitiveType::kFloat32,
        sizeof(float),
        nvidia::gxf::Unexpected{},
        nvidia::gxf::MemoryStorageType::kDevice,
        d_output_,
        [](void*) { return nvidia::gxf::Success; }  // no-op deleter (we own buffer)
    );

    out.emit(out_entity, "image_out");
}

void BeamformOp::stop() {
    if (d_output_) {
        cudaFree(d_output_);
        d_output_ = nullptr;
    }

#ifdef ENABLE_BEAMFORM
    us_beamform_entry_terminate();
#endif

    HOLOSCAN_LOG_INFO("BeamformOp stopped.");
}

}  // namespace ops
