// operators/inference_op.hpp
// Holoscan operator that runs ONNX/TensorRT inference for lesion classification.
// Uses Holoscan's built-in InferenceOp underneath; this wrapper adds
// pre/post-processing and result annotation for Holoviz.
//
// Input:  image_in — [H x W] float32 enhanced ultrasound image (GPU)
// Output: output   — annotated entity with class label + confidence overlay

#pragma once

#include <holoscan/holoscan.hpp>
#include <string>
#include <vector>

namespace ops {

class MedInferenceOp : public holoscan::Operator {
public:
    HOLOSCAN_OPERATOR_FORWARD_ARGS(MedInferenceOp)
    MedInferenceOp() = default;

    void setup(holoscan::OperatorSpec& spec) override;
    void start() override;
    void compute(holoscan::InputContext&    in,
                 holoscan::OutputContext&   out,
                 holoscan::ExecutionContext& ctx) override;
    void stop() override;

private:
    holoscan::Parameter<std::string> model_path_;
    holoscan::Parameter<std::string> backend_;
    holoscan::Parameter<int>         input_width_;
    holoscan::Parameter<int>         input_height_;

    // Class labels matching CNN training order
    std::vector<std::string> class_labels_ = {"benign", "malignant", "normal"};

    float* d_input_resized_ = nullptr;
    float* d_output_scores_ = nullptr;
    int    num_classes_ = 3;

    // TensorRT engine context (opaque pointer to avoid trt headers here)
    void* trt_context_ = nullptr;

    void preprocess(float* d_src, int src_h, int src_w,
                    float* d_dst, int dst_h, int dst_w);
    int  argmax(const float* scores, int n);
};

}  // namespace ops
