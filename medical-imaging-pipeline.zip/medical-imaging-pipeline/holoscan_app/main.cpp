// main.cpp
// Entry point for the Medical Imaging Holoscan pipeline.
//
// Pipeline operator flow:
//   DataSourceOp --> BeamformOp --> EnhanceOp --> InferenceOp --> HolovizOp
//
// Each operator is defined in operators/. MATLAB GPU Coder generated
// CUDA functions are called inside BeamformOp and EnhanceOp.

#include <holoscan/holoscan.hpp>
#include <holoscan/operators/holoviz/holoviz.hpp>
#include <holoscan/operators/inference/inference.hpp>

#include "operators/data_source_op.hpp"
#include "operators/beamform_op.hpp"
#include "operators/enhance_op.hpp"
#include "operators/inference_op.hpp"

#include <iostream>
#include <string>

namespace holoscan {

class MedicalImagingApp : public Application {
public:
    void compose() override {
        using namespace ops;

        // ---- Data Source: streams RF frames from .mat file or ADC -------
        auto source = make_operator<DataSourceOp>(
            "data_source",
            Arg("data_path",  std::string("../data/sample_rf_data.mat")),
            Arg("frame_rate", 30),
            Arg("loop",       true)
        );

        // ---- Beamforming: DAS via MATLAB GPU Coder CUDA -----------------
        auto beamform = make_operator<BeamformOp>(
            "beamform",
            Arg("speed_of_sound", 1540.0f),   // m/s
            Arg("sampling_freq",  40.0e6f),    // Hz
            Arg("element_pitch",  3.0e-4f),    // m
            Arg("num_elements",   128)
        );

        // ---- Enhancement: Wiener + CLAHE via MATLAB GPU Coder CUDA ------
        auto enhance = make_operator<EnhanceOp>(
            "enhance",
            Arg("wiener_kernel_size", 5),
            Arg("clahe_clip_limit",   0.02f)
        );

        // ---- AI Inference: lesion classification via TensorRT -----------
        auto inference = make_operator<MedInferenceOp>(
            "inference",
            Arg("model_path",  std::string("../models/lesion_detector.onnx")),
            Arg("backend",     std::string("trt")),
            Arg("input_width", 224),
            Arg("input_height", 224)
        );

        // ---- Visualization: Holoviz display -----------------------------
        auto viz = make_operator<HolovizOp>(
            "viz",
            Arg("width",        1280u),
            Arg("height",       720u),
            Arg("window_title", std::string("Medical Imaging Pipeline — Real-Time"))
        );

        // ---- Connect operators ------------------------------------------
        add_flow(source,    beamform,  {{"rf_out",       "rf_in"}});
        add_flow(beamform,  enhance,   {{"image_out",    "image_in"}});
        add_flow(enhance,   inference, {{"enhanced_out", "image_in"}});
        add_flow(inference, viz,       {{"output",       "receivers"}});

        // Also route enhanced image directly to viz for side-by-side view
        add_flow(enhance,   viz,       {{"enhanced_out", "receivers"}});
    }
};

}  // namespace holoscan

int main(int argc, char** argv) {
    // Optional: override config via command-line YAML path
    std::string config_path = "pipeline.yaml";
    if (argc > 1) { config_path = argv[1]; }

    auto app = holoscan::make_application<holoscan::MedicalImagingApp>();
    app->config(config_path);

    try {
        app->run();
    } catch (const std::exception& e) {
        std::cerr << "[ERROR] Pipeline failed: " << e.what() << std::endl;
        return EXIT_FAILURE;
    }

    return EXIT_SUCCESS;
}
